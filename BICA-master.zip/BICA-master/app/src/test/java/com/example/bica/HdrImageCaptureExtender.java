package com.example.bica;

public enum HdrImageCaptureExtender {
}
